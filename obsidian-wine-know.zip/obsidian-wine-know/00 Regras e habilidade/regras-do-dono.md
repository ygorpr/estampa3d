# Regras do dono do canal — tudo o que ele já pediu e corrigiu (LER ANTES DE QUALQUER VÍDEO)

Consolidado de meses de conversa. Cada item é um pedido ou uma correção real do dono. Não repita os erros listados.

## 1. Público, idioma e tom
- Canal **Wine Know – Dark Divino**. Público: homens 40+, com dinheiro, que gostam de vinho. MAS o roteiro é escrito para
  **quem NÃO sabe nada de vinho**: toda palavra difícil é explicada na hora ("ânfora: um jarro grande de barro, com duas alças";
  "sobreiro, a árvore da cortiça"; "espumante, o vinho com gás"; "maceração"; "antocianina").
- **Responder e pensar em português** com o dono (ele pediu explicitamente). Mensagens curtas, claras, sem jargão técnico de programação.
- Linha do tempo SEM buracos: se algo existiu, sumiu e voltou, dizer que sumiu e por quanto tempo
  (erro real: "no séc. XVII a cortiça voltou" sem ter dito que tinha sumido por ~1.000 anos).

## 2. Pauta (escolha de temas)
- O dono gosta de **CURIOSIDADES**, não de temas batidos de "dica de compra". Ex. que ele aprovou: por que a garrafa tem 750 ml;
  e antes da rolha?; o buraco no fundo da garrafa; por que a garrafa é verde; quem inventou o champanhe; champanhe no fundo do mar;
  o vinho mais antigo do mundo; por que brindamos; de onde vem a cor do vinho; o ritual da rolha no restaurante; de onde vem a palavra sommelier.
- Quando ele pedir temas: pesquisar e trazer **~10 opções** com 1–2 linhas cada (o gancho e o fato surpreendente), recomendar 2 e esperar a escolha.
- **Pauta SEMPRE pesquisada no Google, no YouTube e nas redes (TikTok, Instagram, Reddit, notícias)** para saber do que o público está
  falando agora; **sempre que a Pauta da esteira ficar sem assunto (ou abaixo de 10), gerar sozinho mais 10 temas novos** a partir dessas pesquisas,
  sem esperar pedido, aprendendo com o que ele aceitou e recusou (ver histórico no painel); trazer **no mínimo 10 temas** na esteira, cada um com o gancho e a evidência ("o que estão falando": vídeo, matéria, dúvida comum).
- Painel de decisões: artefato "Esteira Dark Divino" (https://claude.ai/artifact/1t32YxYY99HV5bq4DAvcAB, código em `painel/esteira.html`).
  O dono aceita/recusa, aprova roteiro e escolhe a thumb arrastando o cartão ou pelos botões; cada decisão me chega como comentário.
  **Escolher a thumb (A/B/C) = aprovar a execução** (pode gerar a voz). Junto com a escolha ele pode mandar um pedido para o vídeo:
  esse pedido é obrigatório de seguir na produção. Não existe mais a etapa separada "Aprovar execução" (pedido do dono, 20/11/2026).
  **Depois da produção vem a REVISÃO:** o vídeo vai para a estação "Revisão" com uma prévia (480p, `painel/previas/`) para ele assistir no painel;
  ele aprova (→ "Entregue e aprovado") ou pede ajustes (volta para Produção com o pedido). Nunca marcar "Entregue" sem a aprovação dele.
  Ler as decisões com ArtifactData (coleção `videos`) e atualizar os cartões (etapa, vez, roteiro, thumbs) conforme o trabalho anda.
- Pesquisa de demanda no YouTube (`scripts/youtube_ideas.py`) ajuda, mas curiosidade boa vale mesmo sem busca (cresce por recomendação/Shorts).
- Um tema pode virar dois vídeos (ex.: rolha no restaurante + palavra "sommelier"). Se surgir um assunto paralelo bom, separar em outro vídeo.

## 3. Pesquisa — nível de aprofundamento exigido
- **"Ir nos confins do universo"**: buscar a origem real, a etimologia, a história completa, a química/física por trás, números,
  datas, nomes, e as curiosidades que quase ninguém sabe. Exemplos do nível esperado:
  - 750 ml: a lenda do fôlego do vidreiro (desmentida) × a explicação do galão inglês (1/6 de galão = 757 ml; barrica 225 L = 300 garrafas) × 75 cl na Europa dos anos 70 e EUA 1979.
  - Cor do vinho: antocianinas, pH (vermelho→roxo→azul), SO2 que descora e volta, pigmentos polimerizados, espectrofotômetro 420/520/620 nm, tijolo com a idade.
  - Sommelier: grego *ságma* → latim *sagmarius* → francês *sommier* (= nosso "somiê", a cama box!) → sommelier; Grande Bouteiller → "butler"; escanção em Portugal; 1969, ~300 Master Sommeliers.
  - Brinde: libação grega, Ovídio em Roma, alemão "bring dir's" → "brinde", "toast" = torrada, mito do veneno, superstições do Brasil (gole pro santo, copo vazio, olhar nos olhos).
- **Ângulo Brasil** sempre que existir (como se faz/vê aqui, palavras em português, costumes).
- **Mito × verdade** dá ótimos ganchos: dizer claramente o que é lenda ("ninguém prova", "é lenda") e o que é comprovado.
- Fontes: só confiáveis (dicionários, museus, órgãos oficiais, estudos científicos/PNAS/PMC, Wine Spectator, Decanter, Jancis Robinson,
  Wine Folly, WSET, Comité Champagne, Britannica). Blog/loja/IA só como pista. Cada fato com link no `pesquisa.md` do vídeo.
- Fonte fraca ou divergente: dizer "a explicação mais aceita", "dizem que", usar faixa ("uns 150"), ou TIRAR do roteiro (e registrar em "Fora do roteiro").
- Fatos não checados ficam marcados "checar antes da voz"; se não achar fonte, tirar a frase e avisar o dono.

## 4. Pronúncia (nomes estrangeiros)
- Toda palavra estrangeira: checar em DICIONÁRIO (IPA) — não mandar "3 gravações para ele escolher". Ele quer: como se escreve, como se fala, a fonte.
- Tabela "Pronúncia" no topo do roteiro: Escreve | Fala | Fonte.
- Na voz vai "como se fala" via `vo/pronuncia.json` (mesmo nº de palavras); a legenda mostra a grafia certa. Ex.:
  `{"Veuve Clicquot": "Vév Clicô", "sommelier": "somelhê", "Pinot Noir": "Pinô Nuár", "blanc de noirs": "blã de nuár", "Shakespeare": "Xêikspir"}`.
- **Veuve Clicquot é a MARCA** (/vœv kli.ko/, "vév cli-KÔ"): não traduzir para "viúva Clicquot". A pessoa é "Madame Clicquot".

## 5. Fluxo de aprovação (OBRIGATÓRIO)
1. Pesquisa → roteiro (tabela) + `pesquisa.md` + tabela de pronúncia + **3 opções de thumb** → enviar e PARAR.
2. Voz (ElevenLabs gasta crédito do dono) **SÓ depois do "aprovado" explícito do roteiro**. Escolher thumb NÃO é aprovar roteiro.
   Mudou qualquer frase? Mostrar de novo e esperar.
3. Depois da voz: cenas → stills de conferência → corrigir → render → conferir contact sheet → enviar vídeo + thumb.
- **Não refazer vídeos já entregues** sem ele pedir. Corrigir só o que ele apontou; refazer só as cenas afetadas (`build.py --shots N N+1`).
- ATENÇÃO ao cache: `build.py` reaproveita `shots/`. Mudou o código? Apagar `shots/` (ou usar `--shots`) — senão o vídeo sai igual (erro real).

## 6. Thumbnail
- 2 linhas que **DIZEM O ASSUNTO** (curiosidade sim, mistério vazio não). Reprovadas: "E ESSE BURACO?", "O INIMIGO INVISÍVEL", "O VILÃO DO VINHO".
  Aprovadas: "POR QUE 750 ML?", "E ANTES DA ROLHA?", "VOCÊ NUNCA REPAROU?", "POR QUE A GARRAFA É VERDE?", "QUEM INVENTOU O CHAMPANHE?",
  "CHAMPANHE NO FUNDO DO MAR", "VINHO DE 1.700 ANOS", "POR QUE A GENTE BRINDA?", "DE ONDE VEM A COR DO VINHO?", "CHEIRAR A ROLHA É ERRO?".
- Sempre 3 opções (imagem única com as 3) + título de YouTube sugerido para cada + recomendação.
- Texto não encosta em nada (garrafa, vitrine). Rosto = ponto focal. Selo PEQUENO centralizado logo abaixo da linha vermelha. Sem brilho forçado.
- Primeiro quadro do vídeo = a thumb idêntica, que ganha vida (`thumbFrame(0)`).

## 7. Personagem e gestos (Sommelier v10)
- Colete e gravata-borboleta vinho #5E1428 (mesma cor). Braços arm3d, **cotovelo sempre para baixo**, sem braço "mole" ou "quebrado".
- Mãos de descanso apoiadas em algo (garrafa, taça, balcão, vitrine) — nunca na cintura, nunca soltas no ar.
- **Mão NUNCA na frente do rótulo**: segura a garrafa pelo GARGALO. Taça pela haste.
- Gestos com ida, pausa e volta. Gole com o vinho sempre nivelado.
- Personagens extras (mergulhador, monge, cientista, burro de carga...) = **personagem de verdade**, detalhado, no estilo do Sommelier
  (erro real: mergulhador era uma "mancha"; agora `diver()` tem máscara, rosto, cilindro, braços, pernas, nadadeiras).
- Cenário combina com o assunto e com o pedido do dono (ex.: bar do navio de cruzeiro, laboratório de análise, restaurante com mesa, museu, adega, oficina do vidreiro).

## 8. Tela, avisos e legendas
- **Avisos (chips) NUNCA sobre o rosto/cabeça** (motor: `chipSafe` empurra para o lado ou para o topo). Conferir no fim da cena (zoom maior).
- Nada encosta na legenda (avisos, garrafas, placas: até y≈880). Texto não sai de placa/cartão.
- **Bolhas e líquidos só dentro do recipiente** (`fluteBubbles` recorta no bojo da taça). Sem bolha na haste.
- Legenda = exatamente a fala, karaokê, **no máximo 2 linhas**. Sem legenda na tabela final e no logo.
- Marca d'água grande e clarinha. Tabela final em 5 cartões dourados, **com tempo para ler: cartões entram com calma e ficam parados ~8 s**,
  depois um fechamento (brinde do Sommelier, música subindo) antes do logo. Erro real (vídeo 12): "não teve final" — pode passar dos 3 min. CTA no canto superior esquerdo. Logo + "Wine Know. Dark Divino."

## 9. Voz e som
- ElevenLabs, voz Paulo, **eleven_v3 com emoção por frase** (voz "C" aprovada), em blocos de 3 frases (`scripts/tts_v3.py`). Logo final sozinho.
- Frases para falar (perguntas, exclamações, curtas). Vídeo FLUIDO, sem capítulos, transição pela fala. ~3 min (até ~3 min 45 s está ok).
- Jazz/blues/piano com sax. Avisar sempre: "o áudio foi medido, não ouvido".

## 10. Comunicação
- Mostrar o que foi feito em frases simples; mandar arquivos (vídeo + thumb; roteiro + pesquisa) pelo SendUserFile.
- Se algo travar (ex.: GitHub sem acesso), avisar UMA vez com o link de solução; não repetir em toda resposta.

## 11. Painel: equipe e custos (pedido do dono, 20/11/2026)
- Seção "A equipe agora" (doc `equipe/agora` no painel): 4 agentes-bonecos executivos — Sofia (pauta), Rafael (pesquisa e roteiro),
  Helena (arte e thumbs) e TRÊS na produção com o mesmo cargo (Otávio, Lucas, Marina: voz, animação, render e ajustes), cada um dono dos seus vídeos — dividir os vídeos aprovados entre os três e rodar em paralelo. SEMPRE atualizar "fazendo" e "fila" de cada um quando um trabalho começa ou termina.
- Ajuste pedido na Revisão: o vídeo FICA na Revisão (estado "Ajustando o vídeo") até voltar para "Sua vez"; não volta para Produção.
- Custo: contar desde o primeiro vídeo. `config/custos.creditosUsadosTotal` = total real do ElevenLabs (o dono informou 160 mil);
  custo médio = total ÷ vídeos prontos. Manter `ledger` com cada geração de voz (vídeo, refação, amostra) e somar os créditos de cada nova voz.
- Cada tarefa da equipe tem barra de progresso: `{"txt","pct","eta"}` ou, se travada, `{"txt","pct","bloqueio"}`; e o agente tem `"esperando"`
  dizendo O QUÊ está esperando (ex.: créditos do ElevenLabs). Atualizar a porcentagem quando cada etapa termina
  (cenas ~50%, stills conferidos ~70%, voz ~85%, render ~95%, na Revisão 100%).
- Tempo de produção médio: cada vídeo pronto recebe `producaoMin` = minutos de trabalho da máquina somados
  (roteiro + thumbs + cenas + voz + render + ajustes). Medir pela duração real de cada agente/render e gravar no doc do vídeo.
- Agente travado: preencher `esperando`, `comoResolver` (passo a passo curto) e `link` (ex.: https://elevenlabs.io/app/subscription).
  O card mostra o botão "Já resolvi, pode continuar", que me manda um aviso: testar na hora (ex.: 1 frase curta de voz) e retomar.
- Gerente: "Beatriz" (esta sessão) coordena tudo; ronda automática de hora em hora (tarefa agendada "Gerente da esteira Dark Divino")
  confere agentes, dispara o que o dono já liberou, atualiza o painel e só chama o dono quando precisa (créditos, acesso, decisão).
- Equipe completa (12): Beatriz (gerente), Sofia (pauta), Rafael (roteiro), **Caio (checador de fatos)**, Helena (thumbs),
  Otávio/Pedro/Júlia/Lucas/Marina (produção, um vídeo cada quando possível), **Larissa (redatora: títulos, descrições e textos do YouTube, Shorts e Reels)**, **Diego (cortes para Shorts/Reels)**.
  - Caio: confere cada fato e cada pronúncia do roteiro em fonte forte ANTES de ir para "Sua vez"; marca o que mudou no "Recado meu".
  - Larissa (REDATORA): para cada vídeo aprovado, escreve 3 opções de título (dizem o assunto, curiosidade sem mistério vazio),
    descrição (com fontes), tags, capítulos e sugestão de horário em `pauta/<v>/youtube.md` e no painel; e, para cada corte do Diego,
    título curto + legenda (caption) + hashtags para Shorts e Reels em `videos/shorts/<slug>-textos.md`.
    NÃO publica (sem acesso à conta do YouTube); o dono publica copiando os textos.
  - Diego: de cada vídeo aprovado, 1 a 3 cortes verticais 1080x1920 de 30–45 s com legenda karaokê, sem voz nova, em `videos/shorts/`.
- Créditos: avisar o dono no painel quando o saldo estimado ficar abaixo de 20 mil créditos (config/custos.alertaCreditos).

## Hierarquia e padrão único (pedido do dono, 20/11)
- O fluxo é fixo e ninguém pula etapa: Sofia sugere → dono aceita → Rafael (pesquisa profunda + roteiro) → Caio (fatos e pronúncia)
  → dono aprova → Helena (thumbs) → dono escolhe → Produção → dono revisa → Diego (cortes) → Larissa (textos e calendário) → dono publica.
- Os 5 produtores produzem EXATAMENTE no mesmo padrão: mesmo kit e motor, mesma voz e configuração, mesmo Sommelier, mesma abertura
  e fechamento, mesma legenda, mesma trilha, mesma conferência de stills. Não pode haver diferença de qualidade entre eles;
  todos seguem `references/brief-producao.md` + `brief-comum.md` sem variação.

## Equipe enxuta (20/11, pedido do dono)
- Pedro e Júlia SAÍRAM. Produção = Otávio, Lucas e Marina. Os vídeos deles passaram para o Otávio
  (doc do vídeo: `produtor: "Otávio"`, `produtorOriginal: "Júlia"|"Pedro"`). Equipe: 10 pessoas.
- O Dark Divino NÃO tem Instagram: nada de Reels no calendário. Só YouTube (longo) e Shorts.
- O canal do YouTube fica numa conta Google separada da 3uniformes; NÃO misturar as contas.

## Contas separadas: Dark Divino x 3uniformes (NÃO misturar)
- Dark Divino (YouTube, conta Google própria) = conta Windsor.ai SEPARADA. Acesso só pela API REST
  `https://connectors.windsor.ai/youtube?date_preset=...&fields=...&select_accounts=108952&api_key=...` (canal "Wine Know"; no endpoint
  /youtube a conta é `108952`, no /all é `youtube__108952`; campos em /youtube/fields),
  com a chave na variável de ambiente `WINDSOR_API_KEY_DARKDIVINO` (ou a que o dono passou na sessão, só em memória) do ambiente de nuvem "estampa3d" (o dono cadastra
  em Configurações do ambiente; NUNCA pedir a chave no chat, nunca gravar em arquivo nem em commit).
- O conector Windsor.ai do claude.ai (ferramentas mcp__Windsor_ai__*) é da 3uniformes: NUNCA usar no painel do Dark Divino.
- Host liberado na rede do ambiente: connectors.windsor.ai.
- Estado em 20/11/2026: canal Wine Know com 0 inscritos, 0 vídeos, 0 visualizações (nada publicado). Calendário: 9, 10, depois 1 a 8.

## Publicador: Rodrigo (20/11)
- Larissa = só REDATORA (títulos, descrição, tags, capítulos, textos dos Shorts). Rodrigo = PUBLICADOR e ANALISTA do canal:
  junta vídeo aprovado + thumb + textos + cortes, monta o calendário, deixa pronto para publicar, lê os números a cada ronda e
  comenta cada cartão do "Painel do canal" (fica na sala dele, `look: publica`). Ele não aperta "publicar": não há acesso de escrita
  ao YouTube; o dono publica/agenda no YouTube Studio. Equipe: 11 pessoas.

## EQUIPE = NO MÁXIMO 8 (20/11, ordem do dono) — não criar cargo novo sem ele pedir
- Beatriz (gerente) · Sofia (pauta) · Rafael (roteiro) · Caio (checagem) · Helena (thumbs) · Otávio (TODA a produção + cortes do Shorts)
  · Larissa (redatora) · Rodrigo (publicador e analista do canal). Saíram: Pedro, Júlia, Lucas, Marina, Diego (vídeos e histórico
  passaram para o Otávio, com `produtorOriginal`). Se precisar de nova função, ACUMULAR num cargo existente, nunca passar de 8.

## PAINEL: NUNCA PUBLICAR SEM TESTAR (erro de 20/11)
- A versão 32 foi publicada sem teste e quebrou o painel inteiro: faltou um ";" antes de uma linha que começa com "[" e o
  JavaScript parou (equipe, "Sua vez" e esteira sumiram). O dono viu o painel "todo cagado".
- Antes de TODA publicação do painel: `node .claude/skills/wine-know-video/scripts/testar_painel.js /caminho/ABSOLUTO/painel/esteira.html`
  tem que dar "OK". Se der "FALHOU", não publicar. Também tirar print do painel e das salas e olhar.
- Mudança pequena e pedida = mexer só no que foi pedido; não reorganizar o layout que o dono aprovou.

## Analista → diretora → equipe (pedido do dono, 20/11)
- Rodrigo (publicador e ANALISTA) faz relatório 48 h depois de cada vídeo publicado e toda segunda-feira (coleção `relatorios`):
  o que aconteceu, deu certo, deu errado, sugestões e ideias, cada um com o número que justifica.
- OBRIGATÓRIO ler os COMENTÁRIOS do canal (`comentariosPublico` em canal/youtube). Toda dúvida do público ou tema que vale vídeo:
  (1) vira tema na Pauta com `doComentario: true`, `origem: "comentario"`, gancho citando o comentário (a Sofia pesquisa e completa);
  (2) aparece para o dono em "Sua vez" como "Pedido do público" — o dono decide se vira vídeo específico;
  (3) fica registrado no relatório (comentarios.duvidas/temas com virouPauta).
- Beatriz (diretora geral) lê o relatório e repassa recados para quem precisa agir: `escritorios/<look>.recados[{em,txt,motivo}]`
  (Sofia: temas; Rafael: gancho/roteiro; Helena: thumb; Otávio: edição/Shorts; Larissa: títulos). Mudança de rumo do canal
  (horário, tipo de tema) vai para o dono aprovar antes.

## Comentário fixado (aprovado pelo dono, 20/11)
- Todo vídeo publicado tem 1 comentário fixado, escrito pela Larissa no youtube.md (seção "Comentário fixado"):
  1ª linha = pergunta ligada ao TÍTULO e ao que foi FALADO no vídeo, fácil de responder (escolha, opinião, experiência):
  ex.: "Você prefere tinto ou rosé?", "Qual o próximo prato que você vai combinar com vinho?", "Abriria a garrafa de 1.700 anos?".
  2ª linha = convite fixo: "E se tiver alguma dúvida de vinho, deixa aqui embaixo: as melhores viram vídeo no canal! 👇"
- Objetivo: fazer as pessoas responderem. O Rodrigo lê as respostas no relatório; dúvidas viram "Pedido do público" na pauta.
- O dono fixa o comentário ao publicar (não temos acesso de escrita ao YouTube).

## Cofre do Obsidian (pedido do dono, 21/11)
- TUDO do Wine Know também vai para o cofre do Obsidian em `C:\Users\User\Desktop\GPT - WINE KNOW` (computador do dono).
- Estrutura: "Wine Know - Inicio.md" (índice) · 00 Regras e habilidade · 01 Videos/<NN-tema>/(roteiro, pesquisa, youtube) · 02 Painel e equipe · 03 Pauta.
  Cópia no repositório: `obsidian-wine-know/` (+ .zip).
- Sempre que algo mudar (regra, roteiro, pacote, relatório), atualizar `obsidian-wine-know/` e, se a pasta do computador estiver
  conectada (Remote Control / sessão local), gravar lá também. Se não estiver, mandar o .zip para o dono.
